-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 19, 2023 at 07:47 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `attendance_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `2csea`
--

CREATE TABLE IF NOT EXISTS `2csea` (
  `id` varchar(43) NOT NULL,
  `name` varchar(43) NOT NULL,
  `java` int(43) NOT NULL DEFAULT '0',
  `dbms` int(43) NOT NULL DEFAULT '0',
  `java_total` int(43) NOT NULL DEFAULT '0',
  `dbms_total` int(43) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `2csea`
--

INSERT INTO `2csea` (`id`, `name`, `java`, `dbms`, `java_total`, `dbms_total`) VALUES
('539', 'ghuna', 1, 10, 1, 9),
('549', 'habeeba', 0, 11, 1, 9),
('543', 'hemu', 1, 12, 1, 9),
('547', 'HarshithaVadla', 0, 5, 1, 9),
('538', 'Gayatri LahariNarahara', 0, 2, 1, 9),
('512', 'AnshuLatha', 1, 0, 1, 0),
('1', 'anshusss', 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `21csea_internals`
--

CREATE TABLE IF NOT EXISTS `21csea_internals` (
  `id` varchar(43) NOT NULL,
  `name` varchar(43) NOT NULL,
  `java_a1` varchar(43) NOT NULL DEFAULT '0',
  `java_a2` varchar(43) NOT NULL DEFAULT '0',
  `java_m1` varchar(43) NOT NULL DEFAULT '0',
  `java_m2` varchar(43) NOT NULL DEFAULT '0',
  `dbms_a1` varchar(43) NOT NULL DEFAULT '0',
  `dbms_a2` varchar(43) NOT NULL DEFAULT '0',
  `dbms_m1` varchar(43) NOT NULL DEFAULT '0',
  `dbms_m2` varchar(43) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `21csea_internals`
--

INSERT INTO `21csea_internals` (`id`, `name`, `java_a1`, `java_a2`, `java_m1`, `java_m2`, `dbms_a1`, `dbms_a2`, `dbms_m1`, `dbms_m2`) VALUES
('543', 'hemu', '0', '45', '45', '0', '10', '10', '10', '10'),
('549', 'habeeba', '0', '66', '66', '0', '9', '9', '9', '9'),
('539', 'ghuna', '0', '36', '36', '0', '7', '7', '7', '7'),
('547', 'harshitha', '0', '88', '88', '0', '8', '8', '8', '8');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` varchar(43) NOT NULL,
  `password` varchar(43) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `password`) VALUES
('11', '11@11'),
('22', '22@22');

-- --------------------------------------------------------

--
-- Table structure for table `cse21_results`
--

CREATE TABLE IF NOT EXISTS `cse21_results` (
  `id` varchar(43) NOT NULL,
  `name` varchar(43) NOT NULL,
  `java` varchar(43) NOT NULL DEFAULT '0',
  `dbms` varchar(43) NOT NULL DEFAULT '0',
  `total` varchar(43) NOT NULL DEFAULT '0',
  `mefa` varchar(43) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cse21_results`
--

INSERT INTO `cse21_results` (`id`, `name`, `java`, `dbms`, `total`, `mefa`) VALUES
('543', 'hemu', '10', '9', '10', '0'),
('549', 'habeeba', '9', '9', '9', '0'),
('539', 'ghana', '9', '8', '7', '0'),
('547', 'HarshithaVadla', '10', '9', '8', '0'),
('538', 'Gayatri LahariNarahara', '10', '10', '12', '0'),
('512', 'AnshuLatha', '0', '0', '0', '0'),
('1', 'anshusss', '0', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE IF NOT EXISTS `lecturer` (
  `id` varchar(43) NOT NULL,
  `password` varchar(43) NOT NULL,
  `firstName` varchar(43) NOT NULL,
  `lastName` varchar(43) NOT NULL,
  `branch` varchar(43) NOT NULL,
  `mobile` varchar(43) NOT NULL,
  `address` varchar(92) NOT NULL,
  `gender` varchar(43) NOT NULL,
  `subject` varchar(43) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`id`, `password`, `firstName`, `lastName`, `branch`, `mobile`, `address`, `gender`, `subject`) VALUES
('1', 'prem@11', 'Prem Kumar', 'Singuluri', 'cse', '99999', '4/75', 'male', 'dbms'),
('2', 'sri@22', 'Sri Lakshmi', 'M', 'cse', '9492969789', 'Kurnool', 'female', 'java'),
('23', '123', 'aaa', 'sss', 'cse', '9182186656', 'Kurnool', 'male', 'java'),
('4', '44@44', 'Hemanth Kumar Reddy', 'Tatagari', 'cse', '9182186656', 'Kurnool', 'male', 'dm'),
('1', '123', 'Jayanarayana', 'Reddy', 'cse', '08919058454', 'Kurnool', 'M', 'AI');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` varchar(43) NOT NULL,
  `role` varchar(43) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role`) VALUES
('543', 'student'),
('549', 'student'),
('1', 'lecturer'),
('11', 'admin'),
('22', 'admin'),
('2', 'lecturer'),
('539', 'student'),
('547', 'student'),
('23', 'lecturer'),
('538', 'student'),
('4', 'lecturer'),
('1', 'lecturer'),
('512', 'student'),
('1', 'student');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `id` varchar(43) NOT NULL,
  `password` varchar(43) NOT NULL,
  `firstName` varchar(43) NOT NULL,
  `lastName` varchar(43) NOT NULL,
  `year` varchar(43) NOT NULL,
  `branch` varchar(43) NOT NULL,
  `section` varchar(43) NOT NULL,
  `mobile` varchar(43) NOT NULL,
  `mail` varchar(43) DEFAULT NULL,
  `address` varchar(92) NOT NULL,
  `fatherName` varchar(43) NOT NULL,
  `motherName` varchar(43) NOT NULL,
  `aadhar` varchar(43) NOT NULL,
  `caste` varchar(43) NOT NULL,
  `religion` varchar(43) NOT NULL,
  `school` varchar(43) NOT NULL,
  `school_grade` varchar(43) NOT NULL,
  `pre_grade` varchar(43) NOT NULL,
  `college` varchar(43) NOT NULL,
  `g11` varchar(43) DEFAULT NULL,
  `g12` varchar(43) DEFAULT NULL,
  `g21` varchar(43) DEFAULT NULL,
  `g22` varchar(43) DEFAULT NULL,
  `g31` varchar(43) DEFAULT NULL,
  `g32` varchar(43) DEFAULT NULL,
  `g41` varchar(43) DEFAULT NULL,
  `g42` varchar(43) DEFAULT NULL,
  `gender` varchar(43) NOT NULL,
  `fee_category` varchar(43) NOT NULL,
  `sem` varchar(43) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `password`, `firstName`, `lastName`, `year`, `branch`, `section`, `mobile`, `mail`, `address`, `fatherName`, `motherName`, `aadhar`, `caste`, `religion`, `school`, `school_grade`, `pre_grade`, `college`, `g11`, `g12`, `g21`, `g22`, `g31`, `g32`, `g41`, `g42`, `gender`, `fee_category`, `sem`) VALUES
('539', 'Gupta@539', 'Ghana Syam', 'Gupta', '2', 'cse', 'a', '9999999999', 'gupta@539', 'Kurnool', 'guptha father', 'gupta mother', '6358602336', 'oc', 'hindu', 'ledu', '10', '10', 'narayana', NULL, NULL, '7', NULL, NULL, NULL, NULL, NULL, 'male', 'reem', '1'),
('543', 'habb@543', 'Habeeba Shafeen', 'Shaik', '2', 'cse', 'a', '9182186656', 'habb@tata', '4/74', 'kabeer ji', 'naseemunnisa ji', '5777', 'oc', 'hindu', 'keshava reddy', '10', '9.75', 'sri chaitanya', NULL, NULL, '10', NULL, NULL, NULL, NULL, NULL, 'female', 'reem', '1'),
('549', 'Hemu@549', 'Hemanth Kumar Reddy', 'Tatagari', '2', 'cse', 'a', '9182186656', 'tata@hemu', '4/74', 'Soma Linga Reddy', 'Hema Latha', '577726983987', 'oc', 'hindu', 'keshavareddy', '9.3', '9.75', 'sri chaitanya', NULL, NULL, '9', NULL, NULL, NULL, NULL, NULL, 'male', 'reem', '1'),
('547', 'Vadla@547', 'Harshitha', 'Vadla', '2', 'cse', 'a', '88888888', 'harshitha@547', 'Kurnool', 'harshitha father', 'harshitha mother', '9999999', 'abc', 'abc', 'dont', '10', '10', 'narayana', NULL, NULL, '8', NULL, NULL, NULL, NULL, NULL, 'female', 'reem', '1'),
('538', 'gg@538', 'Gayatri Lahari', 'Narahara', '2', 'cse', 'a', '777777', 'gayathri@gmail.com', 'Kurnool', 'father', 'mother', '555555', 'abc', 'hindu', 'dont', '10', '10', 'G PULLaiah', NULL, NULL, '12', NULL, NULL, NULL, NULL, NULL, 'female', 'reem', '1'),
('512', '000', 'Anshu', 'Latha', '2', 'cse', 'a', '9999', 'anshu@gmail.com', 'Kurnool', 'x', 'y', 'aaaaa', 'BC - E', 'Hindu', 'K.V.R', '9', '2', 'ss', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'F', 'Reimbursement', '1'),
('1', '123', 'anshu', 'sss', '2', 'cse', 'a', '8919058454', 'habeebashafeen543@gmail.com', '16/79-A2 khadakpura street kurnool', 'x', 'y', '122222', 'BC - E', 'Hindu', 'K.V.R', '9', '2', 'ss', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'F', 'Reimbursement', '1');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE IF NOT EXISTS `subjects` (
  `code` varchar(43) NOT NULL,
  `subject` varchar(43) NOT NULL,
  `faculty` varchar(43) NOT NULL,
  `year` varchar(43) NOT NULL,
  `branch` varchar(43) NOT NULL,
  `sem` varchar(43) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`code`, `subject`, `faculty`, `year`, `branch`, `sem`) VALUES
('A31010', 'java', 'Sri Lakshmi', '2', 'cse', '1'),
('A30011', 'dbms', 'Prem Kumar', '2', 'cse', '1'),
('b0e1a22', 'AI', 'D JayaNarayana Reddy', '3', 'cse', '1'),
('ab123cd', 'mefa', 'HEmanth kumar', '2', 'cse', '1'),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', '');
